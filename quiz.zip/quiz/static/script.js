function startQuiz() {
    const username = document.getElementById("username").value;
    if (username.trim() === "") {
        alert("Please enter your name");
        return;
    }
    localStorage.setItem("username", username);
    window.location.href = "/quiz";
}

document.addEventListener("DOMContentLoaded", function () {
    if (window.location.pathname === "/quiz") {
        fetch("/get_questions")
            .then(response => response.json())
            .then(data => {
                const questionsDiv = document.getElementById("questions");
                data.questions.forEach((q, index) => {
                    let questionHTML = `<p>${index + 1}. ${q.question}</p>`;
                    q.options.forEach((option, i) => {
                        questionHTML += `<input type="radio" name="q${q.id}" value="${i}">${option}<br>`;
                    });
                    questionsDiv.innerHTML += questionHTML;
                });
            });

        document.getElementById("quizForm").onsubmit = function (event) {
            event.preventDefault();
            const formData = new FormData(event.target);
            const answers = {};
            formData.forEach((value, key) => {
                answers[key] = value;
            });
            fetch("/submit_quiz", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ username: localStorage.getItem("username"), answers })
            })
            .then(response => response.json())
            .then(data => {
                localStorage.setItem("quizScore", data.score);
                window.location.href = "/result";
            });
        };
    }
});
