from flask import Flask, render_template, request, redirect, url_for
import pymysql
from config import DB_CONFIG

app = Flask(__name__)

def get_db_connection():
    return pymysql.connect(
        host=DB_CONFIG['host'],
        user=DB_CONFIG['user'],
        password=DB_CONFIG['password'],
        database=DB_CONFIG['database'],
        port=4000,
        charset='utf8mb4',
        cursorclass=pymysql.cursors.DictCursor
    )

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/quiz', methods=['GET'])
def quiz():
    username = request.args.get('username')
    section = request.args.get('section').title()  # Capitalizing section to match DB

    conn = get_db_connection()
    cursor = conn.cursor(pymysql.cursors.DictCursor)
    cursor.execute("SELECT id, question, option1, option2, option3, option4 FROM questions WHERE section = %s ORDER BY RAND() LIMIT 5", (section,))
    questions = cursor.fetchall()
    cursor.close()
    conn.close()

    for q in questions:
        q['options'] = [q.pop('option1'), q.pop('option2'), q.pop('option3'), q.pop('option4')]

    return render_template('quiz.html', questions=questions, username=username, section=section)

@app.route('/submit_quiz', methods=['POST'])
def submit_quiz():
    username = request.form.get("username")
    section = request.form.get("section").title()  # Capitalizing section to match DB
    answers = {key[1:]: value for key, value in request.form.items() if key not in ('username', 'section')}

    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT id, correct_option FROM questions WHERE section = %s", (section,))
    correct_answers = {str(row['id']): str(row['correct_option']) for row in cursor.fetchall()}
    cursor.close()

    print("Correct Answers from DB:", correct_answers)

    score = 0
    for qid, ans in answers.items():
        correct = correct_answers.get(qid)
        print(f"Question ID: {qid}, User Answer: {ans}, Correct Answer: {correct}")
        if str(ans) == str(correct):
            score += 1

    print("Final Score:", score)

    cursor = conn.cursor()
    cursor.execute("INSERT INTO scores (username, score, section) VALUES (%s, %s, %s)", (username, score, section))
    conn.commit()
    cursor.close()
    conn.close()

    return render_template('result.html', username=username, score=score, section=section)

@app.route('/scores')
def scores():
    conn = get_db_connection()
    cursor = conn.cursor(pymysql.cursors.DictCursor)
    cursor.execute("SELECT id, username, score, section FROM scores ORDER BY score DESC")
    scores = cursor.fetchall()
    cursor.close()
    conn.close()

    return render_template('scores.html', scores=scores)

@app.route('/delete/<int:id>', methods=['POST'])
def delete_score(id):
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("DELETE FROM scores WHERE id = %s", (id,))
    conn.commit()
    cursor.close()
    conn.close()

    return redirect(url_for('scores'))

@app.route('/update/<int:id>', methods=['POST'])
def update_username(id):
    new_username = request.form.get("new_username")
    if new_username:
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("UPDATE scores SET username = %s WHERE id = %s", (new_username, id))
        conn.commit()
        cursor.close()
        conn.close()

    return redirect(url_for('scores'))

if __name__ == '__main__':
    app.run(debug=True)







