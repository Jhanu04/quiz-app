DB_CONFIG = {
    'user': 'root',
    'password': 'Universe4D.',
    'host': 'localhost',
    'port': 4000,
    'database': 'quiz_db'
}
