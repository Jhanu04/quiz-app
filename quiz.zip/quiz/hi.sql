CREATE DATABASE quiz_db;
USE quiz_db;

CREATE TABLE questions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    question TEXT NOT NULL,
    option1 VARCHAR(255) NOT NULL,
    option2 VARCHAR(255) NOT NULL,
    option3 VARCHAR(255) NOT NULL,
    option4 VARCHAR(255) NOT NULL,
    correct_option INT NOT NULL,
    section VARCHAR(50) NOT NULL
);

CREATE TABLE scores (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(255) NOT NULL,
    score INT NOT NULL,
    section VARCHAR(50) NOT NULL
);

INSERT INTO questions (question, option1, option2, option3, option4, correct_option, section) VALUES
-- Science questions
('What is the chemical symbol for water?', 'H2O', 'O2', 'CO2', 'N2', 0, 'Science'),
('What planet is closest to the Sun?', 'Venus', 'Mars', 'Mercury', 'Jupiter', 2, 'Science'),
('Which gas do plants use for photosynthesis?', 'Oxygen', 'Carbon Dioxide', 'Nitrogen', 'Hydrogen', 1, 'Science'),
('What is the powerhouse of the cell?', 'Nucleus', 'Ribosome', 'Mitochondria', 'Endoplasmic Reticulum', 2, 'Science'),
('Which of the following is a noble gas?', 'Helium', 'Nitrogen', 'Oxygen', 'Hydrogen', 0, 'Science'),

-- Literature questions
('Who wrote "Pride and Prejudice"?', 'Jane Austen', 'Emily Brontë', 'Charlotte Brontë', 'George Eliot', 0, 'Literature'),
('Which of these is a work by Franz Kafka?', 'Crime and Punishment', 'The Trial', 'The Great Gatsby', '1984', 1, 'Literature'),
('Who wrote the epic poem "Paradise Lost"?', 'John Milton', 'William Blake', 'Geoffrey Chaucer', 'Edmund Spenser', 0, 'Literature'),
('Which Shakespeare play features the characters Rosencrantz and Guildenstern?', 'Hamlet', 'Othello', 'Macbeth', 'King Lear', 0, 'Literature'),
('In George Orwells "1984", what is the name of the totalitarian regimes leader?', 'Big Brother', 'The Party', 'OBrien', 'Winston Smith', 0, 'Literature'),

-- Astronomy questions
('Which planet has the most moons?', 'Saturn', 'Jupiter', 'Uranus', 'Neptune', 0, 'Astronomy'),
('What is the largest planet in our solar system?', 'Earth', 'Saturn', 'Jupiter', 'Neptune', 2, 'Astronomy'),
('The Andromeda galaxy is part of which galaxy group?', 'Local Group', 'Virgo Cluster', 'Hercules Cluster', 'Coma Cluster', 0, 'Astronomy'),
('What is the name of the first man-made satellite?', 'Voyager 1', 'Apollo 11', 'Sputnik 1', 'Hubble', 2, 'Astronomy'),
('Which star is closest to Earth?', 'Alpha Centauri', 'Betelgeuse', 'Proxima Centauri', 'Sirius', 2, 'Astronomy');




drop database quiz_db;
SELECT * FROM scores;

